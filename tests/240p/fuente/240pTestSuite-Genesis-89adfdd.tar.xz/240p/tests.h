/* 
 * 240p Test Suite
 * Copyright (C)2011-2014 Artemio Urbina
 *
 * This file is part of the 240p Test Suite
 *
 * The 240p Test Suite is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * The 240p Test Suite is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with 240p Test Suite; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef TESTS_H
#define TESTS_H

void DropShadowTest();
void StripedSpriteTest();
void ReflexNTiming();
void HScrollTest();
void VScrollTest();
void DrawStripes();
void DrawCheckBoard();
void DrawPhaseCheck();
void SoundTest();
void LEDZoneTest();
void PassiveLagTest();
void Alternate240p480i();
void AudioSyncTest();
void DrawConvergence();
void DisappearingLogo();
void TestSuiteROM();

typedef struct timecode
{
	u16 hours;
	u16 minutes;
	u16 seconds;
	u16 frames;
	u16 type;
	u16 res;
} timecode;

#endif
